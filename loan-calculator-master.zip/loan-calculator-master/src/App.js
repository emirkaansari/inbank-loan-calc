import React from 'react';
import LoanForm from './LoanForm';
import './App.css'
function App() {
  return (
    <div>
    <h1>Loan Application Form</h1>
      <LoanForm />
    </div>
  );
}

export default App;

